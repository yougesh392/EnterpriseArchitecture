INSERT INTO Car VALUES(NULL, 'Silver', 'Volvo', 'S80', 1999);
INSERT INTO Car VALUES(NULL, 'Red', 'Honda', 'Accord', 1997);