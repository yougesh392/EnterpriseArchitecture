package edu.mum.cs544;

public interface ICustomerService {
	public void addCustomer(String name, String email, String street,String city, String zip);
}
