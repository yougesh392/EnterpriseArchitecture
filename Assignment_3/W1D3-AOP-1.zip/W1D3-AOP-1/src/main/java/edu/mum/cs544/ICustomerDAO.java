package edu.mum.cs544;

public interface ICustomerDAO {
	public void save(Customer customer) ;
}
